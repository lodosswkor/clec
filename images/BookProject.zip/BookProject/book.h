#pragma once


typedef struct _book {
    int idx;
    char* code; 
    char* name;
    char* author;
    struct _book* link_prev;
    struct _book* link_next;
} BOOK;

typedef struct _book_library {
    int book_cnt;
    BOOK* book_library;
} BOOK_LIBRARY;


BOOK* addBookObject();
BOOK_LIBRARY* getBookLibraryObject();
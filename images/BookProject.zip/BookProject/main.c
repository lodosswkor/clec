
//--- MS C������ ��� ---------------
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif 
//--------------------------------
#include <stdio.h>
#include "book.h"

BOOK_LIBRARY* book_lib = NULL;

int main() {
	
	addBookObject();
	addBookObject();
	book_lib = getBookLibraryObject();

	printf("%d���� å�� �Է� �Ǿ����ϴ�.\n", book_lib->book_cnt);

	BOOK* curr = book_lib->book_library;

	while(curr != NULL) {
		printf("idx=%d\n", curr->idx);
		curr = curr->link_next;
	}

	return 0; 
}